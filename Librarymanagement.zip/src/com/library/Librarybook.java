package com.library;

public class Librarybook {

	String title;
	String author;
	String isbn;
	boolean available;
	

	public Librarybook(String title, String author, String isbn, boolean available) {

		this.title = title;
		this.author = author;
		this.isbn = isbn;
		this.available = true;
	}

	public void m1() {
		
		this.borrowbook();

		
	}

	void returnbook() {
		available = true;

		System.out.println(title);
		System.out.println(author);
		System.out.println(isbn);
		System.out.println(available);
		System.out.println("");
	}

	void borrowbook() {
		available = false;
		System.out.println(title);
		System.out.println(author);
		System.out.println(isbn);
		System.out.println(available);

	}

	
	public static void main(String[] args) {
	Librarybook a = new Librarybook("Classmate", "Rk grawal", "1234", true);
	Librarybook b = new Librarybook("ppt", "murty", "4567", true);
		Librarybook c = new Librarybook("manvswild", "bearGrills", "09527", true);

		System.out.println("LIBRARY INDEX");
		System.out.println("Available books are:" + "\n" + a.title + "\n" + b.title + "\n" + c.title);//		System.out.println("select the book:");
		System.out.println("book you issued:");
		a.borrowbook();
		System.out.println("book you issued:");
		c.borrowbook();
		System.out.println("select the book you want to return");
		a.returnbook();
		
		
	}

}